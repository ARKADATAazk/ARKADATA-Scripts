ReArkitekt — Component & utility kit for ReaImGui

ReArkitekt is a small, opinionated toolkit on top of ReaImGui for REAPER.
It ships reusable widgets (like a high-quality grid with selection & drag-drop), drawlist effects (marching-ants), theming tokens, and helpers that make building consistent UIs fast—especially if you want them to align with your reARK theme.

Lua root: reark
Brand: ReArkitekt
Scope: ReaImGui-centric UI + small utilities (json/color/math)

